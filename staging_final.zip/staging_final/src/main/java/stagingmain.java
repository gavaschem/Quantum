import javafx.scene.layout.Priority;
import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.concurrent.TimeUnit;

public class stagingmain {
    public static WebDriver driver;

    public stagingmain()
    {
        System.setProperty("webdriver.chrome.driver", "Resources/chromedriver.exe");
        ChromeOptions chromeOptions = new ChromeOptions();
        driver = new ChromeDriver(chromeOptions);
        driver.get("https://newdayatworkpartner.sharepoint.com/:b:/g/EaO6GNj6vvJOsVZKT8KvQxEBCeMo7HRyxLQum2jDmC9Esg");
    }

    @Test
    public void a_login_stage() throws InterruptedException {

        Thread.sleep(5000);
        driver.findElement(By.xpath("//*[@id='pdfViewer-0']//section[@data-annotation-id='12R']/a[contains(@title,'staging.workspace365.net')]")).click();
        driver.manage().window().maximize();
        String parentWindwHandle = driver.getWindowHandle();
        System.out.println(parentWindwHandle);
        for (String handle : driver.getWindowHandles()) {
            if (!handle.equals(parentWindwHandle)) {
                driver.switchTo().window(handle);
            }
        }

        driver.findElement(By.xpath("//*[@name='loginfmt']")).sendKeys("chalenge@qachallenge.onmicrosoft.com");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//input[@id='idSIButton9']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@name='passwd']")).sendKeys("G*EX2Pz+G/H&mxN}");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//input[@value='Sign in']")).click();
        Thread.sleep(2000);
        int mysize = driver.findElements(By.xpath("//input[@value='No']")).size();
        if (mysize==1) {
            driver.findElement(By.xpath("//input[@value='No']")).click();
        }
        b_add_Tile();
        c_edit_Tile();
    }


    public void b_add_Tile() throws InterruptedException {
        driver.findElement(By.xpath("//*[text()='Add tiles']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id='available-predefined-tiles-list']//img[contains(@src,'CRM/Address Book')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@name='addToWorkspace']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Save']")).click();
        Thread.sleep(2000);
    }


    public void c_edit_Tile() throws InterruptedException {
        driver.findElement(By.xpath("//*[text()='Edit your workspace']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//h3[text()='New apps']/../../following-sibling::div//img[contains(@src,'CRM/Address Book')]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Delete from workspace']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Save']")).click();
        Thread.sleep(2000);
    }

    @After
    public void closedriver ()
    {
        driver.quit();
    }
}